import crawler

fetcher = crawler.Fetcher()
toPrint = fetcher.fetch()
fetcher.printDB(toPrint)
