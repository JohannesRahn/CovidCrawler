class CrawledBundesland():
    def __init__(self, bundesland, anzahl, differenz, todesfaelle):
        self.bundesland = bundesland
        self.anzahl = anzahl
        self.differenz = differenz
        self.todesfaelle = todesfaelle
