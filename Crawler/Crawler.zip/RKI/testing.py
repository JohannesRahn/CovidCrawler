from datetime import datetime

toCompare = '20/06/2020'
toCompare2 = '2/06/2020'
toCompareDate = datetime.strptime(toCompare, '%d/%m/%Y')
toBeCompared = datetime.strptime(toCompare2, '%d/%m/%Y')

print(toCompareDate > toBeCompared)
